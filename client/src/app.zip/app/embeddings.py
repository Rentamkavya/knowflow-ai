"""Create Gemini embeddings for document chunks."""

import os

from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()


class MissingGeminiKeyError(RuntimeError):
    """Raised when the required Gemini API key is not configured."""


def embed_texts(texts: list[str], task_type: str) -> list[list[float]]:
    """Convert a list of texts into Gemini embedding vectors."""
    if not texts:
        return []

    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise MissingGeminiKeyError("GEMINI_API_KEY is not configured in the .env file.")

    model = os.getenv("GEMINI_EMBEDDING_MODEL", "gemini-embedding-001")
    client = genai.Client(api_key=api_key)
    result = client.models.embed_content(
        model=model,
        contents=texts,
        config=types.EmbedContentConfig(task_type=task_type),
    )
    return [embedding.values for embedding in (result.embeddings or [])]
