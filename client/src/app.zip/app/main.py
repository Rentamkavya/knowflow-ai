import asyncio
import logging
from uuid import uuid4

import fitz
from fastapi import FastAPI, File, HTTPException, UploadFile
from pydantic import BaseModel, Field
from app.chunking import split_page_text
from app.embeddings import MissingGeminiKeyError, embed_texts
from app.generation import generate_grounded_answer
from app.retrieval import retrieve_chunks

app = FastAPI(title="KnowledgeHub RAG API")
logger = logging.getLogger(__name__)

# Temporary storage for this local demo. Uploaded documents disappear when the
# server restarts; later steps will add chunks and embeddings here.
uploaded_documents: dict[str, dict] = {}


class SearchRequest(BaseModel):
    question: str = Field(min_length=1)
    document_ids: list[str] | None = None
    top_k: int = Field(default=3, ge=1, le=10)


class ChatRequest(BaseModel):
    question: str = Field(min_length=1)
    document_ids: list[str] | None = None
    top_k: int = Field(default=3, ge=1, le=10)


@app.get("/health")
def health_check() -> dict[str, str]:
    """Return a small response to confirm that the API is running."""
    return {"status": "ok"}


@app.post("/api/documents/upload")
async def upload_pdf(file: UploadFile = File(...)) -> dict:
    """Accept a PDF and extract its text page by page."""
    filename = file.filename or "uploaded.pdf"
    if not filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Please upload a PDF file.")

    pdf_bytes = await file.read()
    if not pdf_bytes.startswith(b"%PDF-"):
        raise HTTPException(status_code=400, detail="The uploaded file is not a valid PDF.")

    try:
        with fitz.open(stream=pdf_bytes, filetype="pdf") as pdf:
            pages = [
                {"page_number": page_number, "text": page.get_text().strip()}
                for page_number, page in enumerate(pdf, start=1)
            ]
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Could not read this PDF.") from exc

    document_id = str(uuid4())
    chunks = [
        {
            "text": chunk_text,
            "filename": filename,
            "page_number": page["page_number"],
        }
        for page in pages
        for chunk_text in split_page_text(page["text"])
    ]

    try:
        vectors = await asyncio.to_thread(
            embed_texts,
            [chunk["text"] for chunk in chunks],
            "RETRIEVAL_DOCUMENT",
        )
    except MissingGeminiKeyError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        # Do not expose API keys or provider internals in the response.
        raise HTTPException(
            status_code=502,
            detail="Gemini could not create embeddings. Check the API key, quota, and server log.",
        ) from exc

    if len(vectors) != len(chunks):
        raise HTTPException(status_code=502, detail="Gemini returned an unexpected number of embeddings.")
    for chunk, vector in zip(chunks, vectors):
        chunk["embedding"] = vector

    uploaded_documents[document_id] = {
        "filename": filename,
        "pages": pages,
        "chunks": chunks,
    }
    preview = " ".join(page["text"] for page in pages).strip()[:500]

    return {
        "document_id": document_id,
        "filename": filename,
        "page_count": len(pages),
        "extracted_characters": sum(len(page["text"]) for page in pages),
        "chunk_count": len(chunks),
        "embedding_count": len(vectors),
        "embedding_dimensions": len(vectors[0]) if vectors else 0,
        "preview": preview,
        "message": "PDF uploaded and text extracted.",
    }


@app.post("/api/search")
async def search_documents(request: SearchRequest) -> dict:
    """Return the most relevant chunks for a question, with their citations."""
    if not uploaded_documents:
        raise HTTPException(status_code=400, detail="Upload a PDF before searching.")

    if request.document_ids is None:
        selected_ids = list(uploaded_documents)
    else:
        selected_ids = request.document_ids
        missing_ids = [doc_id for doc_id in selected_ids if doc_id not in uploaded_documents]
        if missing_ids:
            raise HTTPException(status_code=404, detail="One or more document IDs were not found.")

    chunks = [
        {**chunk, "document_id": doc_id}
        for doc_id in selected_ids
        for chunk in uploaded_documents[doc_id]["chunks"]
        if "embedding" in chunk
    ]
    if not chunks:
        raise HTTPException(status_code=400, detail="No embedded text chunks are available to search.")

    try:
        results = await asyncio.to_thread(
            retrieve_chunks,
            request.question.strip(),
            chunks,
            request.top_k,
        )
    except MissingGeminiKeyError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Gemini could not embed the search question")
        raise HTTPException(
            status_code=502,
            detail="Gemini could not embed the question. Check the key, quota, and server log.",
        ) from exc

    return {
        "question": request.question,
        "results": [
            {
                "filename": item["filename"],
                "page_number": item["page_number"],
                "text": item["text"],
                "similarity": round(item["similarity"], 4),
                "document_id": item["document_id"],
            }
            for item in results
        ],
    }


@app.post("/api/chat")
async def chat(request: ChatRequest) -> dict:
    """Retrieve relevant PDF passages, then generate a cited answer with Gemini."""
    if not uploaded_documents:
        raise HTTPException(status_code=400, detail="Upload a PDF before asking a question.")

    if request.document_ids is None:
        selected_ids = list(uploaded_documents)
    else:
        selected_ids = request.document_ids
        missing_ids = [doc_id for doc_id in selected_ids if doc_id not in uploaded_documents]
        if missing_ids:
            raise HTTPException(status_code=404, detail="One or more document IDs were not found.")

    chunks = [
        {**chunk, "document_id": doc_id}
        for doc_id in selected_ids
        for chunk in uploaded_documents[doc_id]["chunks"]
        if "embedding" in chunk
    ]
    if not chunks:
        raise HTTPException(status_code=400, detail="No embedded text chunks are available to search.")

    try:
        retrieved = await asyncio.to_thread(
            retrieve_chunks,
            request.question.strip(),
            chunks,
            request.top_k,
        )
    except MissingGeminiKeyError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Gemini could not embed the chat question")
        raise HTTPException(
            status_code=502,
            detail="Gemini could not embed the question. Check the key, quota, and server log.",
        ) from exc

    try:
        answer = await asyncio.to_thread(
            generate_grounded_answer,
            request.question.strip(),
            retrieved,
        )
    except MissingGeminiKeyError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        logger.exception("Gemini answer generation failed")
        raise HTTPException(
            status_code=502,
            detail="Gemini could not generate the answer. Check the key, quota, and server log.",
        ) from exc

    return {
        "answer": answer,
        "sources": [
            {
                "source_id": f"S{index}",
                "filename": item["filename"],
                "page_number": item["page_number"],
                "excerpt": item["text"],
                "similarity": round(item["similarity"], 4),
            }
            for index, item in enumerate(retrieved, start=1)
        ],
    }
