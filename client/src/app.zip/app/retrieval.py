"""Find the most relevant embedded chunks for a question."""

import math

from app.embeddings import embed_texts


def cosine_similarity(left: list[float], right: list[float]) -> float:
    """Measure the direction similarity between two embedding vectors."""
    if len(left) != len(right) or not left:
        return 0.0
    dot = sum(a * b for a, b in zip(left, right))
    left_norm = math.sqrt(sum(value * value for value in left))
    right_norm = math.sqrt(sum(value * value for value in right))
    if left_norm == 0 or right_norm == 0:
        return 0.0
    return dot / (left_norm * right_norm)


def retrieve_chunks(
    question: str,
    chunks: list[dict],
    top_k: int = 3,
) -> list[dict]:
    """Embed a question, rank chunks by cosine similarity, return the best ones."""
    question_vector = embed_texts([question], "RETRIEVAL_QUERY")[0]
    ranked = []
    for chunk in chunks:
        score = cosine_similarity(question_vector, chunk["embedding"])
        ranked.append({**chunk, "similarity": score})
    ranked.sort(key=lambda item: item["similarity"], reverse=True)
    return ranked[:top_k]
